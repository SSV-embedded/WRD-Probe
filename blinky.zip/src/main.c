#include <stdio.h>
#include <zephyr/kernel.h>
#include <zephyr/drivers/gpio.h>
#include <assert.h>

#define LED_RED         DT_ALIAS(led0)
#define LED_GREEN       DT_ALIAS(led1)
#define LED_BLUE        DT_ALIAS(led2)

#define LED             LED_RED

int main(void) {
	static const struct gpio_dt_spec led = GPIO_DT_SPEC_GET(LED, gpios);
	gpio_pin_configure_dt(&led, GPIO_OUTPUT_ACTIVE);

	unsigned cnt = 0;
	while (1) {
		if (cnt % 2 == 0) {
			gpio_pin_set_dt(&led, 1);
		} else {
			gpio_pin_set_dt(&led, 0);
		}

		cnt = cnt + 1;

		k_msleep(1000);
	}

	return 0;
}
