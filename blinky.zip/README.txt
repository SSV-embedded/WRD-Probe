This sample extends the same-named Zephyr sample to verify it with Nordic development kits.

Source code and basic configuration files can be found in the corresponding folder structure in zephyr/samples/basic/blinky.
